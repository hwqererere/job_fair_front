const fuli=function(self,data){
  
}