module.exports = {
  serverPrefix: 'https://res-1251120695.cos.ap-shanghai.myqcloud.com/',
    Bucket: 'res-1251120695',
    Region: 'ap-shanghai',
    
    albumDir: 'mhjczx/data/',
};